import os
import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="SAYIM AI JARVIS Backend")

COMFYUI_URL = os.getenv("COMFYUI_URL", "").rstrip("/")
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "").rstrip("/")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "qwen3")

class PromptRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=8000)

@app.get("/health")
async def health():
    return {"ok": True, "service": "SAYIM AI JARVIS"}

@app.post("/api/chat")
async def chat(req: PromptRequest):
    if not LLM_BASE_URL:
        return {"status": "not_configured", "message": "LLM_BASE_URL সেট করতে হবে।", "prompt": req.prompt}
    url = LLM_BASE_URL.rstrip("/") + "/chat/completions"
    headers = {"Authorization": f"Bearer {LLM_API_KEY}"} if LLM_API_KEY else {}
    payload = {"model": LLM_MODEL, "messages": [{"role": "user", "content": req.prompt}]}
    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post(url, json=payload, headers=headers)
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text[:1000])
    data = r.json()
    return {"status": "ok", "answer": data.get("choices", [{}])[0].get("message", {}).get("content", "")}

@app.post("/api/video/generate")
async def generate_video(req: PromptRequest):
    if not COMFYUI_URL:
        return {"status": "not_configured", "message": "GPU server-এর COMFYUI_URL configure করতে হবে।", "prompt": req.prompt}
    # ComfyUI needs a model-specific workflow JSON. This endpoint checks connectivity;
    # workflow submission is deliberately not fabricated without the installed model/workflow.
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(COMFYUI_URL + "/system_stats")
    if r.status_code >= 400:
        raise HTTPException(502, "ComfyUI server reachable নয়।")
    return {
        "status": "connected",
        "message": "ComfyUI connected. Model-specific Wan workflow JSON এখন configure করতে হবে।",
        "prompt": req.prompt,
        "comfyui": COMFYUI_URL
    }
