# SAYIM AI JARVIS

Starter Android client + Python backend scaffold for a Bengali AI assistant and video-generation control panel.

## Important status
This is a **starter scaffold**, not a finished autonomous phone-control app or a working text-to-video engine yet.
The Android client sends prompts to a backend. The backend can call an OpenAI-compatible Qwen endpoint and check a ComfyUI server.
A real Wan video workflow JSON, GPU hosting, authentication, job polling, media download, voice/TTS, permissions, and end-to-end tests still need configuration.

## Build APK automatically
1. Push this project to the `main` branch of your GitHub repository.
2. Open **Actions**.
3. Select **Build Android APK** and press **Run workflow**, or push a commit.
4. Download `SAYIM-AI-JARVIS-debug-apk` from the successful workflow's Artifacts.

## Backend
```bash
cd backend
python -m venv .venv
pip install -r requirements.txt
export LLM_BASE_URL="https://YOUR_OPENAI_COMPATIBLE_ENDPOINT/v1"
export LLM_API_KEY="YOUR_KEY"
export LLM_MODEL="qwen3"
export COMFYUI_URL="https://YOUR_GPU_HOST"
uvicorn main:app --host 0.0.0.0 --port 8000
```
Expose backend over HTTPS. Do not put API keys in the Android app or GitHub source.

## Android
Open the root folder in Android Studio and build `:app:assembleDebug`.
The app requires an HTTPS backend URL in its first field.
