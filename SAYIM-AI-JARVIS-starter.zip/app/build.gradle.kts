plugins { id("com.android.application") }

android {
    namespace = "com.sayim.jarvis"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sayim.jarvis"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
