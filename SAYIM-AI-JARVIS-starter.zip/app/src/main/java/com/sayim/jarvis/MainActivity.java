package com.sayim.jarvis;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.*;

public class MainActivity extends Activity {
    EditText serverInput, promptInput;
    TextView status, output;
    Button chatButton, videoButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 24);
        root.setBackgroundColor(0xFF071B18);

        TextView title = new TextView(this);
        title.setText("SAYIM AI JARVIS");
        title.setTextColor(0xFFFFD76A);
        title.setTextSize(26);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("বাংলা AI Assistant • Video Studio");
        sub.setTextColor(0xFFE6F3EF);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 8, 0, 20);
        root.addView(sub);

        serverInput = new EditText(this);
        serverInput.setSingleLine(true);
        serverInput.setText("https://YOUR-BACKEND-URL");
        serverInput.setHint("Backend URL (HTTPS)");
        serverInput.setTextColor(0xFFFFFFFF);
        serverInput.setHintTextColor(0xFFB8C8C2);
        root.addView(serverInput);

        promptInput = new EditText(this);
        promptInput.setHint("বাংলায় লিখুন: কী তৈরি করতে চান?");
        promptInput.setTextColor(0xFFFFFFFF);
        promptInput.setHintTextColor(0xFFB8C8C2);
        promptInput.setMinLines(3);
        promptInput.setGravity(Gravity.TOP);
        root.addView(promptInput);

        chatButton = new Button(this); chatButton.setText("AI-কে জিজ্ঞাসা করুন");
        root.addView(chatButton);
        videoButton = new Button(this); videoButton.setText("ভিডিও জেনারেশন শুরু");
        root.addView(videoButton);

        status = new TextView(this); status.setTextColor(0xFFFFD76A);
        status.setPadding(0, 16, 0, 8); root.addView(status);
        output = new TextView(this); output.setTextColor(0xFFFFFFFF);
        output.setTextSize(16); root.addView(output);

        setContentView(root);
        chatButton.setOnClickListener(v -> send("/api/chat"));
        videoButton.setOnClickListener(v -> send("/api/video/generate"));
    }

    void send(String path) {
        String base = serverInput.getText().toString().trim();
        String prompt = promptInput.getText().toString().trim();
        if (!base.startsWith("https://") || base.contains("YOUR-BACKEND")) {
            status.setText("প্রথমে একটি HTTPS Backend URL বসান।");
            return;
        }
        if (prompt.isEmpty()) { status.setText("আগে নির্দেশ লিখুন।"); return; }
        status.setText("কাজ চলছে...");
        chatButton.setEnabled(false); videoButton.setEnabled(false);
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                JSONObject body = new JSONObject();
                body.put("prompt", prompt);
                URL u = new URL(base.replaceAll("/+$", "") + path);
                c = (HttpURLConnection)u.openConnection();
                c.setRequestMethod("POST");
                c.setConnectTimeout(20000); c.setReadTimeout(60000);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                try(OutputStream os = c.getOutputStream()) {
                    os.write(body.toString().getBytes("UTF-8"));
                }
                int code = c.getResponseCode();
                InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] b = new byte[4096]; int n;
                while((n=is.read(b))!=-1) buf.write(b,0,n);
                String result = buf.toString("UTF-8");
                runOnUiThread(() -> {
                    status.setText("Server response: HTTP " + code);
                    output.setText(result);
                    chatButton.setEnabled(true); videoButton.setEnabled(true);
                });
            } catch(Exception e) {
                runOnUiThread(() -> {
                    status.setText("সংযোগ হয়নি: " + e.getMessage());
                    chatButton.setEnabled(true); videoButton.setEnabled(true);
                });
            } finally { if(c!=null) c.disconnect(); }
        }).start();
    }
}
